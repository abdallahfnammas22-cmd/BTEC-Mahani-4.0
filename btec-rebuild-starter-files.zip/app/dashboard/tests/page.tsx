const levels = ["سهل", "متوسط", "صعب", "شديد الصعوبة"];

export default function TestsPage() {
  return (
    <section className="section-space">
      <div className="container-page space-y-8">
        <div className="card-panel p-8">
          <h1 className="text-3xl font-extrabold text-slate-950">مركز الاختبارات</h1>
          <p className="mt-3 text-slate-600">
            هذه شاشة بداية نظيفة لمركز الاختبارات. لاحقًا سنربطها ببنك أسئلة حقيقي وقاعدة بيانات وجلسات ونتائج.
          </p>
        </div>

        <div className="grid gap-4 lg:grid-cols-4">
          {levels.map((item) => (
            <div key={item} className="card-panel p-5 text-center">
              <h2 className="text-xl font-bold text-slate-900">{item}</h2>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
