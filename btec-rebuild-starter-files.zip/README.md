# BTEC Rebuild Starter

هذه **نسخة نظيفة من الصفر** لتبدأ إعادة بناء المشروع بشكل صحيح.

## الهدف
هذه الحزمة ليست نسخة نهائية جاهزة للتشغيل الكامل، لكنها:
- نقطة بداية مرتبة
- هيكل مشروع واضح
- صفحات أساسية
- ملفات إعداد
- Prisma schema أولية
- وثائق تنفيذ داخل `docs/`

## كيف تستخدمها
1. ارفعها إلى GitHub
2. افتحها محليًا
3. شغّل:
   ```bash
   npm install
   cp .env.example .env
   npm run dev
   ```
4. لاحقًا:
   - اربط قاعدة بيانات PostgreSQL
   - فعّل Prisma migrations
   - أضف Auth
   - ابنِ بنك الأسئلة والورش والبحث

## ملاحظات مهمة
- هذه الحزمة موجهة إلى **GitHub + Vercel**
- ليست موجهة إلى GitHub Pages
- GitHub هنا للكود
- Vercel أو منصة مشابهة هنا لتشغيل التطبيق

## الخطوات التالية
اقرأ الملفات داخل `docs/` بهذا الترتيب:
1. `01-roadmap.md`
2. `02-architecture.md`
3. `03-database-plan.md`
4. `04-deployment.md`
5. `05-github-checklist.md`
