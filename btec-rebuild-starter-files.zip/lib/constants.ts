export const APP_NAME = "بوابة BTEC الذكية للتعلم والتوجيه المهني";
export const ADVISOR_NAME = "BTEC Advisor";

export const SPECIALIZATIONS = [
  {
    title: "صيانة المركبات",
    description: "مسار يركز على الفحص والصيانة وتشخيص الأعطال."
  },
  {
    title: "الكهرباء",
    description: "مسار يركز على الأنظمة الكهربائية والتطبيقات التقنية."
  },
  {
    title: "تكنولوجيا الإنتاج",
    description: "مسار يركز على التصنيع، الجودة، والعمليات الإنتاجية."
  }
];
