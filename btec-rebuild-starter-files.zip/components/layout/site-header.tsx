import Link from "next/link";
import { APP_NAME } from "@/lib/constants";

const items = [
  { href: "/", label: "الرئيسية" },
  { href: "/dashboard", label: "بوابة الطالب" },
  { href: "/dashboard/tests", label: "الاختبارات" },
  { href: "/login", label: "تسجيل الدخول" }
];

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-50 border-b border-slate-200 bg-white/90 backdrop-blur">
      <div className="container-page flex flex-wrap items-center justify-between gap-4 py-4">
        <div>
          <p className="text-sm font-extrabold text-slate-900">مدرسة دير أبي سعيد الثانوية المهنية للبنين</p>
          <p className="text-xs text-slate-500">{APP_NAME}</p>
        </div>

        <nav className="flex flex-wrap items-center gap-4">
          {items.map((item) => (
            <Link key={item.href} href={item.href} className="text-sm font-bold text-slate-700 transition hover:text-brand">
              {item.label}
            </Link>
          ))}
        </nav>
      </div>
    </header>
  );
}
