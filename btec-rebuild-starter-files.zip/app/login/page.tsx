export default function LoginPage() {
  return (
    <section className="section-space">
      <div className="container-page max-w-2xl">
        <div className="card-panel p-8">
          <h1 className="text-3xl font-extrabold text-slate-950">تسجيل الدخول</h1>
          <p className="mt-3 text-slate-600">
            هذه شاشة Placeholder كبداية. في المرحلة التالية سيتم ربطها بـ Auth حقيقي.
          </p>

          <div className="mt-8 grid gap-4">
            <input
              className="rounded-xl border border-slate-300 px-4 py-3"
              placeholder="البريد الإلكتروني"
            />
            <input
              className="rounded-xl border border-slate-300 px-4 py-3"
              placeholder="كلمة المرور"
              type="password"
            />
            <button className="btn-primary w-fit">دخول</button>
          </div>
        </div>
      </div>
    </section>
  );
}
