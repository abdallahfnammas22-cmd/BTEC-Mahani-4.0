const cards = [
  "آخر درس",
  "آخر اختبار",
  "التقدم العام",
  "الورش المكتملة",
  "مستوى التحدي الحالي",
  "توصية اليوم"
];

export default function DashboardPage() {
  return (
    <section className="section-space">
      <div className="container-page space-y-8">
        <div className="card-panel p-8">
          <h1 className="text-3xl font-extrabold text-slate-950">بوابة الطالب</h1>
          <p className="mt-3 text-slate-600">
            هذه هي الشاشة التي سنحوّلها لاحقًا إلى Dashboard حقيقية مرتبطة بالبيانات والجلسات والنتائج.
          </p>
        </div>

        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {cards.map((card) => (
            <div key={card} className="card-panel p-5">
              <p className="text-sm font-bold text-slate-500">{card}</p>
              <p className="mt-3 text-lg font-bold text-slate-900">قيمة تجريبية</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
