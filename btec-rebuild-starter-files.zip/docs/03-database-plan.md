# 03 — خطة قاعدة البيانات

## الجداول الأولى
- users
- questions

## الجداول التالية
- subjects
- units
- lessons
- test_sessions
- student_answers
- workshops
- workshop_submissions
- career_results
