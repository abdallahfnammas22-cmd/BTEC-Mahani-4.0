# 02 — المعمارية

## الواجهة
- Next.js

## الخلفية
- API داخل Next.js في البداية

## البيانات
- PostgreSQL
- Prisma ORM

## لاحقًا
- Auth.js
- Search Engine
- File Storage
- Admin Panel
