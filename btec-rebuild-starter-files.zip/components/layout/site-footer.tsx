export function SiteFooter() {
  return (
    <footer className="mt-20 bg-brand-dark py-8 text-center text-white">
      <div className="container-page">
        <p className="font-bold">بوابة BTEC الذكية للتعلم والتوجيه المهني</p>
        <p className="mt-2 text-sm text-slate-300">
          هذه نسخة بداية نظيفة لإعادة البناء بشكل صحيح.
        </p>
      </div>
    </footer>
  );
}
