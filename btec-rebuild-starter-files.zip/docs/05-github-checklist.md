# 05 — قائمة GitHub

## يجب أن ترفع
- app/
- components/
- lib/
- prisma/
- docs/
- package.json
- tsconfig.json
- next.config.ts
- README.md
- .env.example
- .gitignore

## لا ترفع
- node_modules/
- .next/
- .env
