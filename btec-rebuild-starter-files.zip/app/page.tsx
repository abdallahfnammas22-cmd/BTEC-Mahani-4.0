import Link from "next/link";
import { SectionTitle } from "@/components/shared/section-title";
import { SPECIALIZATIONS, ADVISOR_NAME } from "@/lib/constants";

export default function HomePage() {
  return (
    <>
      <section className="section-space">
        <div className="container-page grid items-center gap-10 lg:grid-cols-2">
          <div className="space-y-6">
            <span className="inline-flex rounded-full bg-brand-light px-4 py-2 text-sm font-bold text-brand">
              إعادة بناء صحيحة من الصفر
            </span>
            <h1 className="text-4xl font-extrabold leading-tight text-slate-950 md:text-6xl">
              نبني المنصة
              <br />
              كتطبيق حقيقي
            </h1>
            <p className="text-lg leading-9 text-slate-600">
              هذه النسخة تضع الأساس الصحيح: واجهة منظمة، هيكل ملفات واضح، وخطة تنفيذ
              تقودنا إلى Backend وقاعدة بيانات وبحث واختبارات وورش عملية حقيقية.
            </p>
            <div className="flex flex-wrap gap-3">
              <Link href="/dashboard" className="btn-primary">
                افتح بوابة الطالب
              </Link>
              <Link href="/docs/01-roadmap.md" className="btn-secondary">
                ابدأ من خطة التنفيذ
              </Link>
            </div>
          </div>

          <div className="card-panel p-8">
            <p className="text-sm font-bold text-brand">{ADVISOR_NAME}</p>
            <h2 className="mt-3 text-2xl font-extrabold text-slate-950">ماذا سنبني أولًا؟</h2>
            <div className="mt-5 grid gap-3">
              {[
                "تسجيل دخول فعلي",
                "بوابة طالب منظمة",
                "بنك أسئلة مرتبط بقاعدة بيانات",
                "جلسات اختبار ونتائج",
                "ورش عملية وتقييم",
                "بحث حقيقي مرتبط بالمحتوى"
              ].map((item) => (
                <div key={item} className="rounded-2xl border border-slate-200 p-4 text-sm font-medium text-slate-700">
                  {item}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="section-space bg-white">
        <div className="container-page space-y-10">
          <SectionTitle
            eyebrow="التخصصات"
            title="المسارات التي ستبنى عليها المنصة"
            description="هذه التخصصات مثبتة داخل المشروع، ويمكن ربطها لاحقًا بالمواد والوحدات والأسئلة والورش."
          />

          <div className="grid gap-5 lg:grid-cols-3">
            {SPECIALIZATIONS.map((item) => (
              <div key={item.title} className="card-panel p-6">
                <h3 className="text-2xl font-bold text-slate-900">{item.title}</h3>
                <p className="mt-3 text-sm leading-7 text-slate-600">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
